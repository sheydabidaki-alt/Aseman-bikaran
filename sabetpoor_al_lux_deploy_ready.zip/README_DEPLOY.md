# Sabetpoor AL Lux – Deploy Ready

This package includes configs for Vercel, Render, and Docker.